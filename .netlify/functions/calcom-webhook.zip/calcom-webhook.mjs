
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/calcom-webhook.mjs
var NOCODB_URL = "https://admin.saged.club";
var NOCODB_TOKEN = "niIrlNav-3NkyiB82YDtPznbKLfhs0pptRIg4HKb";
var NOCODB_BASE = "p2txdvaha72xsn4";
var NOCODB_TABLE = "mzerh9imrwgjmuf";
var calcom_webhook_default = async (request) => {
  if (request.method !== "POST") return new Response("OK", { status: 200 });
  let payload;
  try {
    payload = await request.json();
  } catch {
    return new Response("Bad JSON", { status: 400 });
  }
  const booking = payload.payload ?? payload;
  const attendee = booking.attendees?.[0] ?? {};
  const responses = booking.responses ?? {};
  const promoCode = booking.metadata?.promo ?? "";
  const amount = promoCode ? 25 : 30;
  const row = {
    "Name": responses.name?.value ?? attendee.name ?? "",
    "Email": responses.email?.value ?? attendee.email ?? "",
    "Phone": responses.attendeePhoneNumber?.value ?? "",
    "Date": booking.startTime?.split("T")[0] ?? "",
    "Amount": amount,
    "Final Amount": amount,
    "Promo Code": promoCode,
    "Payment": "Stripe",
    "Booking Status": "Confirmed",
    "Notes": responses.notes?.value ?? ""
  };
  const res = await fetch(`${NOCODB_URL}/api/v1/db/data/noco/${NOCODB_BASE}/${NOCODB_TABLE}`, {
    method: "POST",
    headers: { "xc-token": NOCODB_TOKEN, "Content-Type": "application/json" },
    body: JSON.stringify(row)
  });
  return new Response(JSON.stringify({ ok: res.ok }), { status: res.ok ? 200 : 500 });
};
var config = { path: "/api/calcom-webhook" };
export {
  config,
  calcom_webhook_default as default
};
